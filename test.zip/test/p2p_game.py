#!/usr/bin/env python3
"""
P2P Game Client - Render Signaling + STUN Public IP
Commands: ready | waiting | peers | exit
"""

import asyncio
import json
import socket
import os
import aiohttp
import random
import stun  # pip install pystun3
import time

shutdown_event = asyncio.Event()

class P2PGameClient:
    def __init__(self):
        self.config = self.load_config()
        self.game_sock = None
        self.udp_sock = None
        self.peers = {}
        self.public_ip = None  # STUN discovered!
        self.public_port = None
        self.session = None
        self.my_state = "waiting"
        
    def load_config(self):
        if not os.path.exists("p2p_game.json"):
            config = {
                "game": {"udp_port": 0, "host": "127.0.0.1"},
                "p2p": {
                    "signaling_url": "https://your-app.onrender.com/punch_in",
                    "room_id": "HIMALAYA123",
                    "initial_state": "waiting",
                    "poll_interval": 2,
                    "stun_servers": ["stun.l.google.com:19302"]
                }
            }
            with open("p2p_game.json", "w") as f:
                json.dump(config, f, indent=2)
            print("✅ Created p2p_game.json")
        
        with open("p2p_game.json") as f:
            config = json.load(f)
        
        # Auto game port
        if config["game"]["udp_port"] == 0:
            test_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            test_sock.bind(("127.0.0.1", 0))
            config["game"]["udp_port"] = test_sock.getsockname()[1]
            test_sock.close()
        
        print(f"✅ Room: {config['p2p']['room_id']} | Game UDP: {config['game']['udp_port']}")
        return config
    
    async def discover_public_ip(self):
        """STUN public IP discovery"""
        print("🔍 Discovering public IP via STUN...")
        try:
            # retry count
            count = 0

            while count< 5:
                nat_type, external_ip, external_port = stun.get_ip_info()
                self.public_ip = external_ip
                self.public_port = external_port
                print(f"✅ STUN Public: {self.public_ip}:{self.public_port}")

                if not self.public_ip:
                    print('IP retrival failed trying again')
                    count += 1
                    await asyncio.sleep(1)
                else:
                    count = 10

        except Exception as e:
            print(f"⚠️ STUN failed: {e}")
            self.public_ip = "127.0.0.1"  # Fallback
            self.public_port = self.udp_sock.getsockname()[1]
            print(f"🔄 Fallback: {self.public_ip}:{self.public_port}")
    
    async def create_sockets(self):
        self.game_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.game_sock.bind((self.config["game"]["host"], self.config["game"]["udp_port"]))
        self.game_sock.setblocking(False)
        
        self.udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.public_port = random.randint(54000, 55000)
        self.udp_sock.bind(("0.0.0.0", self.public_port))
        self.udp_sock.setblocking(False)
        
        # STUN discovery AFTER socket bind
        await self.discover_public_ip()
        self.my_addr = f"{self.public_ip}:{self.public_port}"
        print(f"✅ P2P Ready: {self.my_addr}")
    
    async def signaling_loop(self):
        print("📡 Signaling started...")
        counter = 0
        while not shutdown_event.is_set() and self.my_state != "connected":
            counter += 1
            try:
                is_ready = self.my_state == "ready"
                async with self.session.post(self.config["p2p"]["signaling_url"], json={
                    "ip": self.public_ip,
                    "port": self.public_port,
                    "room": self.config["p2p"]["room_id"],
                    "ready": is_ready,
                    "waiting": self.my_state == "waiting"
                }) as response:
                    data = await response.json()
                    print(f"📡 [{counter}] {data['status']} | Players: {data.get('players', 0)} | You: {self.my_state}")
                    
                    if data["status"] == "PUNCH":
                        targets = data["targets"]
                        print(f"🎯 [{counter}] Punching {len(targets)} targets!")
                        for target in targets:
                            peer_id = f"{target['ip']}:{target['port']}"
                            if peer_id not in self.peers:
                                self.peers[peer_id] = (target["ip"], target["port"])
                                punch = json.dumps({"type": "punch"}).encode()
                                self.udp_sock.sendto(punch, (target["ip"], target["port"]))
                                print(f"👊 [{counter}] Punched {peer_id}!")
                        
                        self.my_state = "connected"
            except Exception as e:
                print(f"⚠️ [{counter}] Error: {e}")
            
            await asyncio.sleep(self.config["p2p"]["poll_interval"])
        
        # Report success to server then END
        if self.my_state == "connected":
            print("🎉 All connected! Notifying server...")
            async with self.session.post(self.config["p2p"]["signaling_url"], json={
                "ip": self.public_ip, "port": self.public_port, "room": self.config["p2p"]["room_id"],
                "success": True  # "I'm done with signaling!"
            }) as response:
                print("✅ Signaling complete - P2P LIVE!")
    
    async def command_listener(self):
        print("\n🎮 Commands: ready | waiting | peers | exit")
        while not shutdown_event.is_set():
            try:
                cmd = await asyncio.get_event_loop().run_in_executor(None, input, "")
                cmd = cmd.strip().lower()
                
                if cmd == "ready":
                    self.my_state = "ready"
                    print("✅ → READY")
                elif cmd == "waiting":
                    self.my_state = "waiting"
                    print("⏳ → WAITING")
                elif cmd == "peers":
                    print(f"👥 Peers ({len(self.peers)}): {list(self.peers.keys())}")
                elif cmd == "exit":
                    shutdown_event.set()
                    print("👋 Exiting...")
                else:
                    print("❓ ready/waiting/peers/exit")
            except:
                pass
    
    async def udp_listener(self):
        while not shutdown_event.is_set():
            try:
                data, addr = self.udp_sock.recvfrom(1024)
                msg = json.loads(data.decode())
                peer_id = f"{addr[0]}:{addr[1]}"
                
                print(f"📨 {msg['type']} from {peer_id}")
                
                if msg["type"] == "punch" and peer_id not in self.peers:
                    self.peers[peer_id] = addr
                    reply = json.dumps({"type": "punch_reply"}).encode()
                    self.udp_sock.sendto(reply, addr)
                    print(f"👋 Connected {peer_id}!")
                
                elif msg["type"] == "game_data":
                    self.game_sock.sendto(data, ("127.0.0.1", self.config["game"]["udp_port"]))
            except BlockingIOError:
                await asyncio.sleep(0.01)
    
    async def game_forwarder(self):
        print("🎮 Game forwarder + AUTO-TEST mode started...")
        frame = 0
        
        while not shutdown_event.is_set():
            try:
                # 1. Listen for REAL game UDP
                data, addr = self.game_sock.recvfrom(4096)
                if addr[0] == "127.0.0.1":
                    packet = {"type": "game_data", **json.loads(data.decode())}
                    for peer_addr in list(self.peers.values()):
                        self.udp_sock.sendto(json.dumps(packet).encode(), peer_addr)
                
            except BlockingIOError:
                # 2. AUTO-GENERATE test packets (if connected)
                if self.peers and frame % 30 == 0:  # Every 0.5s (60 FPS sim)
                    test_packet = {
                        "type": "position",
                        "x": 100 + (frame * 0.5) % 800,  # Moving right
                        "y": 400 + 50 * (frame // 60 % 2),  # Bobbing up/down
                        "player_id": "TEST_PLAYER",
                        "frame": frame,
                        "timestamp": time.time()
                    }
                    
                    print(f"🧪 AUTO-SEND [{frame}]: {test_packet['x']:.0f},{test_packet['y']:.0f} → {len(self.peers)} peers")
                    
                    # Forward to peers (keeps NAT alive!)
                    for peer_addr in list(self.peers.values()):
                        self.udp_sock.sendto(json.dumps(test_packet).encode(), peer_addr)
            
            frame += 1
            await asyncio.sleep(1/60)  # 60 FPS loop

    
    async def start(self):
        await self.create_sockets()
        self.my_state = self.config["p2p"]["initial_state"]
        
        async with aiohttp.ClientSession() as session:
            self.session = session
            print("🚀 P2P LIVE!")
            print("💬 Type commands:")
            
            await asyncio.gather(
                self.signaling_loop(),
                self.command_listener(),
                self.udp_listener(),
                self.game_forwarder()
            )

async def main():
    client = P2PGameClient()
    try:
        await client.start()
    finally:
        if hasattr(client, 'game_sock'):
            client.game_sock.close()
        if hasattr(client, 'udp_sock'):
            client.udp_sock.close()
        print("\n✅ Cleanup")

if __name__ == "__main__":
    asyncio.run(main())
